import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { TimerService } from '../timer.service';

@Component({
  selector: 'app-start-stop-functionality',
  templateUrl: './start-stop-functionality.component.html',
  styleUrls: ['./start-stop-functionality.component.css']
})
export class StartStopFunctionalityComponent implements OnInit {

  @ViewChild('timer') timer: ElementRef;

  intervalHandler: any;
  clickcount: number = 0;
  started: number = 0;
  paused: number = 0;
  ended: boolean = false;
  pausedValue: number = 0;
  pausedArray = [];
  startedTimestampArray = [];
  pausedTimestampArray = [];

  constructor(private timerService: TimerService) {
  }

  ngOnInit() {
  }

  inputTimeEvent(timerValue: number) {
    if (timerValue > 0) {
      this.clickcount++;
      if ((this.clickcount) % 2 == 1) {
        this.intervalHandler = setInterval(() => this.ticker(this.pausedValue-- > 0 ? this.pausedValue-- : timerValue--), 1000);
        this.startedTasks();
      }
      else if ((this.clickcount) % 2 == 0) {
        clearInterval(this.intervalHandler);
        this.pausedTasks();
      }
    }
  }

  startedTasks() {
    this.started++;
    this.startedTimestampArray.push(new Date());
    this.timerService.startedDate.next(this.startedTimestampArray);
    this.timerService.count.next([this.started, this.paused]);
  }

  pausedTasks() {
    this.paused++;
    this.pausedTimestampArray.push(new Date());
    this.timerService.pausedDate.next(this.pausedTimestampArray);
    this.timerService.inputTime.next(this.pausedValue);
    this.timerService.count.next([this.started, this.paused]);
    this.pausedArray.push(this.pausedValue);
  }

  ticker(timerValue: number) {
    if (timerValue) {
      this.timerService.inputTime.next(timerValue);
    }
    else if (timerValue === 0) {
      this.timerService.inputTime.next(timerValue);
      clearInterval(this.intervalHandler);
      this.ended = true;
    }
    this.pausedValue = timerValue;
  }

  reset() {
    clearInterval(this.intervalHandler);
    this.clickcount = 0;
    this.started = 0;
    this.paused = 0;
    this.ended = false;
    this.pausedValue = 0;
    this.pausedArray = [];
    this.startedTimestampArray = [];
    this.pausedTimestampArray = [];
    this.timerService.inputTime.next(0);
    this.timerService.count.next([0, 0]);
    this.timerService.startedDate.next([]);
    this.timerService.pausedDate.next([]);
    this.timer.nativeElement.value = "";
  }
}

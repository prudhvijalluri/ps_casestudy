import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable()
export class TimerService {
    inputTime = new Subject<number>();
    count = new Subject<any>();
    startedDate = new Subject<any>();
    pausedDate = new Subject<any>();
}
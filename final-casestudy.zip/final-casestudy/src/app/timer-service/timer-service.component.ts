import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { TimerService } from './timer.service';

@Component({
  selector: 'app-timer-service',
  templateUrl: './timer-service.component.html',
  styleUrls: ['./timer-service.component.css']
})
export class TimerServiceComponent implements OnInit, OnDestroy {

  inputTime: number;
  counts = [];
  pausedDate = [];
  startedDate = [];
  constructor(private timerService: TimerService) { }

  inputTimeSub: Subscription;
  countSub: Subscription;
  startedDateSub: Subscription;
  pausedDateSub: Subscription;

  ngOnInit(): void {
    this.getInputTime();
    this.getCount();
    this.getStartedDate();
    this.getPausedDate();
  }

  getInputTime() {
    this.inputTimeSub = this.timerService.inputTime.subscribe((data) => {
      this.inputTime = data;
    });
  }

  getCount() {
    this.countSub = this.timerService.count.subscribe((data) => {
      this.counts = data;
    });
  }

  getStartedDate() {
    this.startedDateSub = this.timerService.startedDate.subscribe((data) => {
      this.startedDate = data;
    });
  }

  getPausedDate() {
    this.pausedDateSub = this.timerService.pausedDate.subscribe((data) => {
      this.pausedDate = data;
    });
  }

  ngOnDestroy() {
    this.inputTimeSub.unsubscribe();
    this.countSub.unsubscribe();
    this.startedDateSub.unsubscribe();
    this.pausedDateSub.unsubscribe();
  }
}

import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { TimerServiceComponent } from "./timer-service.component";
import { ClickCounterComponent } from './click-counter/click-counter.component';
import { CountdownTimerComponent } from './countdown-timer/countdown-timer.component';
import { LogsComponent } from './logs/logs.component';
import { StartStopFunctionalityComponent } from './start-stop-functionality/start-stop-functionality.component';
import { FormsModule } from "@angular/forms";
import { CommonModule, DatePipe } from "@angular/common";
import { TimerService } from "./timer.service";

@NgModule({
    declarations: [
        TimerServiceComponent,
        ClickCounterComponent,
        CountdownTimerComponent,
        LogsComponent,
        StartStopFunctionalityComponent
    ],
    imports: [
        FormsModule,
        CommonModule,
        RouterModule.forChild([{ path: '', component: TimerServiceComponent }]),
    ],
    providers: [
        DatePipe,
        TimerService
    ]
})
export class TimerServiceModule {

}
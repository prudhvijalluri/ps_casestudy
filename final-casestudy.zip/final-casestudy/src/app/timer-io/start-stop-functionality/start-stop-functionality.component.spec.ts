import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StartStopFunctionalityComponent } from './start-stop-functionality.component';

describe('StartStopFunctionalityComponent', () => {
  let component: StartStopFunctionalityComponent;
  let fixture: ComponentFixture<StartStopFunctionalityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StartStopFunctionalityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StartStopFunctionalityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

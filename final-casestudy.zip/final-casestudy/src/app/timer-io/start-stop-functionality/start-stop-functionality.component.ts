import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';

@Component({
  selector: 'app-start-stop-functionality',
  templateUrl: './start-stop-functionality.component.html',
  styleUrls: ['./start-stop-functionality.component.css']
})
export class StartStopFunctionalityComponent implements OnInit {
  @Output() inputTime = new EventEmitter<number>();
  @Output() count = new EventEmitter<any>();
  @Output() startedDate = new EventEmitter<any>();
  @Output() pausedDate = new EventEmitter<any>();

  @ViewChild('timer') timer: ElementRef;

  intervalHandler: any;
  clickcount: number = 0;
  started: number = 0;
  paused: number = 0;
  ended: boolean = false;
  pausedValue: number = 0;
  pausedArray = [];
  startedTimestampArray = [];
  pausedTimestampArray = [];
  constructor() {
  }

  ngOnInit() {

  }

  inputTimeEvent(timerValue: number) {
    if (timerValue > 0) {
      this.clickcount++;
      if ((this.clickcount) % 2 == 1) {
        this.intervalHandler = setInterval(() => this.ticker(this.pausedValue-- > 0 ? this.pausedValue-- : timerValue--), 1000);
        this.startedTasks();
      }
      else if ((this.clickcount) % 2 == 0) {
        clearInterval(this.intervalHandler);
        this.pausedTasks();
      }
    }
  }

  startedTasks() {
    this.started++;
    this.startedTimestampArray.push(new Date());
    this.startedDate.emit(this.startedTimestampArray);
    this.count.emit([this.started, this.paused]);
  }

  pausedTasks() {
    this.paused++;
    this.pausedTimestampArray.push(new Date());
    this.pausedDate.emit(this.pausedTimestampArray);
    this.inputTime.emit(this.pausedValue);
    this.count.emit([this.started, this.paused]);
    this.pausedArray.push(this.pausedValue);
  }

  ticker(timerValue: number) {
    if (timerValue) {
      this.inputTime.emit(timerValue);
    }
    else if (timerValue === 0) {
      this.inputTime.emit(timerValue);
      clearInterval(this.intervalHandler);
      this.ended = true;
    }
    this.pausedValue = timerValue;
  }

  reset() {
    clearInterval(this.intervalHandler);
    this.clickcount = 0;
    this.started = 0;
    this.paused = 0;
    this.ended = false;
    this.pausedValue = 0;
    this.pausedArray = [];
    this.startedTimestampArray = [];
    this.pausedTimestampArray = [];
    this.inputTime.emit(0);
    this.count.emit([0, 0]);
    this.startedDate.emit([]);
    this.pausedDate.emit([]);
    this.timer.nativeElement.value = "";
  }
}

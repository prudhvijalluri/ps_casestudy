import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timer-io',
  templateUrl: './timer-io.component.html',
  styleUrls: ['./timer-io.component.css']
})
export class TimerIOComponent implements OnInit {
  inputTime: number;
  counts = [];
  pausedDate = [];
  startedDate = [];
  constructor() { }

  ngOnInit(): void {
  }

  getInputTime(value: number) {
    this.inputTime = value;
  }

  getCount(array: any) {
    this.counts = array;
  }

  getStartedDate(value: any) {
    this.startedDate = value;
  }

  getPausedDate(value: any) {
    this.pausedDate = value;
  }
}

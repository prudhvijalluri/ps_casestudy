import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { TimerIOComponent } from "./timer-io.component";
import { CountdownTimerComponent } from './countdown-timer/countdown-timer.component';
import { StartStopFunctionalityComponent } from './start-stop-functionality/start-stop-functionality.component';
import { LogsComponent } from './logs/logs.component';
import { ClickCounterComponent } from './click-counter/click-counter.component';
import { FormsModule } from "@angular/forms";
import { CommonModule, DatePipe } from "@angular/common";

@NgModule({
    declarations: [
        TimerIOComponent,
        CountdownTimerComponent,
        StartStopFunctionalityComponent,
        LogsComponent,
        ClickCounterComponent
    ],
    imports: [
        FormsModule,
        CommonModule,
        RouterModule.forChild([{ path: '', component: TimerIOComponent }]),
    ],
    providers: [
        DatePipe
    ]
})
export class TimerIOModule {

}
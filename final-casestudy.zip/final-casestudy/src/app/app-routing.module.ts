import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DefaultComponent } from './default/default.component';

const routes: Routes = [
  { path: '', component: DefaultComponent },
  {
    path: 'dynamicdiv',
    loadChildren: () => import("./dynamic-div/dynamic-div.module").then(m => m.DynamicDivModule)
  },
  {
    path: 'ecommerce',
    loadChildren: () => import("./ecommerce/ecommerce.module").then(m => m.EcommerceModule)
  },
  {
    path: 'image',
    loadChildren: () => import("./image/image.module").then(m => m.ImageModule)
  },
  {
    path: 'studentmarks',
    loadChildren: () => import("./student-marks/student-marks.module").then(m => m.StudentMarksModule)
  },
  {
    path: 'timerio',
    loadChildren: () => import("./timer-io/timer-io.module").then(m => m.TimerIOModule)
  },
  {
    path: 'timerservice',
    loadChildren: () => import("./timer-service/timer-service.module").then(m => m.TimerServiceModule)
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { DynamicDivComponent } from "./dynamic-div.component";

@NgModule({
    declarations: [
        DynamicDivComponent
    ],
    imports: [
        RouterModule.forChild([{ path: '', component: DynamicDivComponent }]),
    ]
})
export class DynamicDivModule {

}
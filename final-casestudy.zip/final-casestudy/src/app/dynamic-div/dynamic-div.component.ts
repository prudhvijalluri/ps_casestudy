import { applySourceSpanToStatementIfNeeded } from '@angular/compiler/src/output/output_ast';
import { Component, HostListener, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-dynamic-div',
  templateUrl: './dynamic-div.component.html',
  styleUrls: ['./dynamic-div.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DynamicDivComponent implements OnInit {
  j = 0;
  i = 0;
  lastScrollTop = 0;
  constructor() { }

  ngOnInit() {
    this.dynamicDiv();
    this.dynamicDiv();
    this.dynamicDiv();
    this.dynamicDiv();
  }

  @HostListener('window:scroll') onScrollEvent() {
    var st = window.pageYOffset;
    if (st > this.lastScrollTop) {
      this.j++;
      if (this.j % 15 == 0)
        this.dynamicDiv();
    }
    this.lastScrollTop = st <= 0 ? 0 : st;
  }

  dynamicDiv() {
    this.i++;
    var ele = document.createElement("div");
    ele.setAttribute("class", 'div-style');
    ele.innerHTML = `<button id='${this.i}' (click)="alertFn(${this.i})">Alert</button>`;
    document.querySelector('.dynamic-divs').appendChild(ele);
    var alertbtn = document.getElementById(`${this.i}`);
    alertbtn.addEventListener('click', this.alertFn);
  }

  alertFn(i: any) {
    alert("Button in " + i.srcElement.id + " th div clicked");
  }
}

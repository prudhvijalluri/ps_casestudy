import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { ImageComponent } from "./image.component";

@NgModule({
    declarations: [
        ImageComponent
    ],
    imports: [
        RouterModule.forChild([{ path: '', component: ImageComponent }]),
    ]
})
export class ImageModule {

}
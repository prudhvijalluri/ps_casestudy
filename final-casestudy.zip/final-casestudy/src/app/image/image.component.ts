import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ImageComponent implements OnInit {
  constructor() { }

  ngOnInit() {
    this.loopOver();
  }

  loopOver() {
    for (var i = 1; i <= 8; i++) {
      var ele = document.createElement("div");
      ele.setAttribute("class", `list${i} image-border`);
      document.querySelector(`.list${i - 1}`).appendChild(ele);
    }
    ele.innerHTML = "<p class='text-content'>A floating banner text which keeps on rotating</p>";
  }
}

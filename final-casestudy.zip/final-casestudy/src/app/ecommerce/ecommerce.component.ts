import { Component, OnInit } from '@angular/core';
import { courses } from './items.model';
import { faThLarge, faBars } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-ecommerce',
  templateUrl: './ecommerce.component.html',
  styleUrls: ['./ecommerce.component.css']
})
export class EcommerceComponent implements OnInit {
  faThLarge = faThLarge;
  faBars = faBars;
  courses = courses;
  constructor() { }

  ngOnInit(): void {
    this.courses = this.courses.sort((low, high) => low.price - high.price);
  }

  showGrid() {
    document.getElementById("grid-view").style.display = "block";
    document.getElementById("list-view").style.display = "none";
  }

  showList() {
    document.getElementById("grid-view").style.display = "none";
    document.getElementById("list-view").style.display = "block";
  }

  sort(e: any) {
    switch (e.target.value) {
      case "low":
        {
          this.courses = this.courses.sort((low, high) => low.price - high.price);
          break;
        }

      case "high":
        {
          this.courses = this.courses.sort((low, high) => high.price - low.price);
          break;
        }
      default: {
        this.courses = this.courses.sort((low, high) => low.price - high.price);
        break;
      }

    }
    return this.courses;

  }

}

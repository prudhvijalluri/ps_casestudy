export var courses = [
    {
        id: 1,
        title: "AI",
        price: 1234
    },
    {
        id: 2,
        title: "ML",
        price: 1111
    },
    {
        id: 3,
        title: "IOT",
        price: 1453
    },
    {
        id: 4,
        title: "Augmented Analytics",
        price: 1786
    },
    {
        id: 5,
        title: "Big Data",
        price: 1876
    },
    {
        id: 6,
        title: "Blockchain",
        price: 2671
    },
    {
        id: 7,
        title: "Cloud",
        price: 4789
    },
    {
        id: 8,
        title: "Virtual Reality",
        price: 5555
    },
    {
        id: 9,
        title: "Digital twins",
        price: 4376
    },
    {
        id: 10,
        title: "Language Processing",
        price: 3876
    },
    {
        id: 11,
        title: "Voice Interfaces",
        price: 9853
    },
    {
        id: 12,
        title: "ChatBots",
        price: 5600
    },
    {
        id: 13,
        title: "Computer Vision",
        price: 6200
    },
    {
        id: 14,
        title: "Facial Recognition",
        price: 9999
    },
    {
        id: 15,
        title: "Robots",
        price: 8799
    },
    {
        id: 16,
        title: "Cobots",
        price: 2999
    },
    {
        id: 17,
        title: "Autonomous Vehicles",
        price: 3999
    },
    {
        id: 18,
        title: "5G",
        price: 1011
    },
    {
        id: 19,
        title: "Genomics",
        price: 2000
    },
    {
        id: 20,
        title: "Gene Editing",
        price: 3111
    },
    {
        id: 21,
        title: "Machine Co-creativity",
        price: 2199
    },
    {
        id: 22,
        title: "Augmented Design",
        price: 5999
    },
    {
        id: 23,
        title: "Drones",
        price: 3123
    },
    {
        id: 24,
        title: "Aeriel Vehicles",
        price: 4555
    },
    {
        id: 25,
        title: "Cybersecurity",
        price: 5666
    },
    {
        id: 26,
        title: "Quantum Computing",
        price: 2777
    },
    {
        id: 27,
        title: "Robotic Automation",
        price: 3256
    },
    {
        id: 28,
        title: "Micro Moments",
        price: 4321
    },
    {
        id: 29,
        title: "3D & 4D Printing",
        price: 3899
    },
    {
        id: 30,
        title: "Big Data",
        price: 2751
    },
    {
        id: 31,
        title: "Nano Technology",
        price: 9999
    },
    {
        id: 32,
        title: "Material Science",
        price: 6578
    },
    {
        id: 33,
        title: "HTML",
        price: 5000
    },
    {
        id: 34,
        title: "CSS",
        price: 7000
    },
    {
        id: 35,
        title: "JavaScript",
        price: 9999
    },
    {
        id: 36,
        title: "Bootstrap",
        price: 1999
    },
    {
        id: 37,
        title: "jQuery",
        price: 2900
    },
    {
        id: 38,
        title: "Angular",
        price: 9000
    },
    {
        id: 39,
        title: "React",
        price: 8000
    },
    {
        id: 40,
        title: "Node.js",
        price: 7000
    },
];

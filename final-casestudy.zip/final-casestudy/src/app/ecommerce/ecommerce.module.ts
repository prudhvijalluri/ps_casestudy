import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { EcommerceComponent } from "./ecommerce.component";
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
    declarations: [
        EcommerceComponent
    ],
    imports: [
        CommonModule,
        FontAwesomeModule,
        RouterModule.forChild([{ path: '', component: EcommerceComponent }]),
    ]
})
export class EcommerceModule {

}
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SortPipe } from "./sort.pipe";
import { StudentMarksComponent } from "./student-marks.component";

@NgModule({
    declarations: [
        StudentMarksComponent,
        SortPipe
    ],
    imports: [
        CommonModule,
        FormsModule,
        RouterModule.forChild([{ path: '', component: StudentMarksComponent }]),
    ],
    providers: [
        SortPipe
    ]
})
export class StudentMarksModule {

}
import { Component, OnInit } from '@angular/core';
import { SortPipe } from './sort.pipe';

@Component({
  selector: 'app-student-marks',
  templateUrl: './student-marks.component.html',
  styleUrls: ['./student-marks.component.css']
})
export class StudentMarksComponent implements OnInit {
  Name = 0;
  Section = 0;
  Class = 0;
  Sub1 = 0;
  Sub2 = 0;
  Sub3 = 0;
  keyArray = [];
  copyJSON = [];
  count = 0;
  dummyJSON = {
    "Name": ["asfd", "asdf", "asdf", "asfd"],
    "Class": [3, 3, 3, 3],
    "Section": ["D", "E", "F", "A"],
    "Sub1": [23, 23, 26, 34],
    "Sub2": [54, 45, 34, 34],
    "Sub3": [65, 67, 45, 71]
  }
  constructor(private sortPipe: SortPipe) { }

  ngOnInit() {
    this.getkeyData();
  }

  getkeyData() {
    for (let key in this.dummyJSON) {
      this.keyArray.push(key);
    }
  }

  eventHandler(e) {
    switch (e) {
      case "Name":
        this.execute("Name", ++this.Name);
        break;
      case "Class":
        this.execute("Class", ++this.Class);
        break;
      case "Section":
        this.execute("Section", ++this.Section);
        break;
      case "Sub1":
        this.execute("Sub1", ++this.Sub1);
        break;
      case "Sub2":
        this.execute("Sub2", ++this.Sub2);
        break;
      case "Sub3":
        this.execute("Sub3", ++this.Sub3);
        break;
    }
  }

  execute(header, count) {
    if (count == 1) {
      this.copyJSON[header] = this.dummyJSON[header].slice();
      this.dummyJSON[header] = this.dummyJSON[header].sort();
      //this.dummyJSON[header]=this.sortPipe.transform(this.dummyJSON[header],"asc");
    }
    else if (count == 2) {
      this.dummyJSON[header] = this.dummyJSON[header].reverse();
      // this.dummyJSON[header]=this.sortPipe.transform(this.dummyJSON[header],"desc");
    }
    else
      this.dummyJSON[header] = this.copyJSON[header];
  }
}

